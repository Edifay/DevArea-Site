import requests


class ChallengeException(Exception):
    pass


class InvalidToken(ChallengeException):
    pass


def constructData(data):
    return {"data": str(data), "toShow": ""}


def printMessage(prefix, message):
    message = message.replace("\n", " \n\n")

    output = f" {prefix} "
    size = 0
    i = 0
    while i < len(message):
        if size > 85:
            if message[i] != ' ':
                if i != 0 and message[i - 1] != ' ':
                    output += "-"
                i -= 1
            output += f"\n {prefix} "
            size = 1
        elif i + 1 < len(message) and message[i] == '\n':
            output += f"\n {prefix} "
            size = 0
            i += 1
        else:
            size += 1
            output += message[i]
        i += 1

    print(output)

class Client:
    def __init__(self, token, url="https://devarea.fr/data/"):
        self.token = token
        self.url = url
        self.sessionId = self.createSession()

    def createSession(self):
        r = requests.get(f"{self.url}/challenges/create_session?key={self.token}&lang=PYTHON")
        if r.status_code == 500:
            raise InvalidToken()
        return r.json()["data"]

    def getChallengeAccomplished(self):
        r = requests.get(f"{self.url}/challenges/challenges_accomplished?key={self.token}")
        return r.json()

    def start(self):
        printMessage(">>", "start")
        return self.executeOnChallenge("start")

    def loadChallenge(self, challenge):
        printMessage(">>", "load " + challenge)
        r = requests.get(f"{self.url}/challenges/load_challenge?sessionId={self.sessionId}&challenge={challenge}")
        toShow = r.json()["toShow"]
        printMessage("<<", toShow)
        return None

    def submit(self, data):
        printMessage(">>", data)
        return self.executeOnChallenge("", constructData(data))

    def executeOnChallenge(self, command, body=None):
        if body is None:
            body = {"data": "", "toShow": ""}
        r = requests.post(f"{self.url}/challenges/execute_on_challenge/{command}?sessionId={self.sessionId}", json=body).json()
        printMessage("<<", r["toShow"])
        return r["data"]
