from client.client import Client

client = Client("NP56MNz5hJ6a5qC")

client.loadChallenge("tutoriel")
client.start()

#client.submit();
