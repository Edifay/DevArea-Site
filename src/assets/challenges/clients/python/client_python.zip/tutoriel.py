from client.client import Client

client = Client(" Votre clef challenge ici. ")

client.loadChallenge("tutoriel")
client.start()

# client.submit()
