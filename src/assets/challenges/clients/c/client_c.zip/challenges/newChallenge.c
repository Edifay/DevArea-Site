/**
 * Si vous n'avez pas encore résolu le tutoriel,
 * rendez-vous dans 'tutoriel.c'.
 */

/**
 * Pour créer un programme pour résoudre un autre challenge,
 * il suffit de créer un nouveau fichier '<nom_du_challenge>.c',
 * contenant une fonction 'main()'.
 *
 * Vous pouvez copier le code ci-dessous.
 */

#include "../client/client.h"

int main() {
    initDefaultClient("" /*" Votre clef challenge ici ! "*/);
    loadChallenge("" /**/);
    return 0;
}