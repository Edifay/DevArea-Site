#include "../client/client.h"
#include <stdio.h>


/**
 * Lancez ce fichier !
 */
int main() {
    initDefaultClient(""/*" Votre clef challenge ici ! "*/);

    loadChallenge("tutoriel");
    start();

    /* submit(); */
    return 0;
}
