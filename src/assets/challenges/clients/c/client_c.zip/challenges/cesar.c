#include <stdio.h>

#include "../client/client.h"

int main(int argc, char** args) {
    initClientWithDomain("NP56MNz5hJ6a5qC" /*" Votre clef challenge ici ! "*/, "http://localhost:8192/");
    loadChallenge("Cesar" /**/);

    char *result = start();

    printf("RESULT : %s\n", result);

    return 0;
}
