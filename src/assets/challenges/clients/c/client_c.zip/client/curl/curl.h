#ifndef CLIENT_C_CURL_H
#define CLIENT_C_CURL_H

#ifdef _WIN32
#define CURL_PATH ".\\libcurl\\curl.exe"
#else
#define CURL_PATH "curl"
#endif

#define MAX_PARAM_FIELDS_LENGTH 200

typedef enum {
    POST,
    GET
} RequestType;

typedef struct {
    char name[MAX_PARAM_FIELDS_LENGTH];
    char value[MAX_PARAM_FIELDS_LENGTH];
} Param;

#define MAX_SIMPLE_PACKET_DATA_LENGTH 65536 /* 2^(16) bytes */

typedef struct {
    char data[MAX_SIMPLE_PACKET_DATA_LENGTH];
    char toShow[MAX_SIMPLE_PACKET_DATA_LENGTH];
} SimplePacket;

#define MAX_URL_LENGTH 4096 /* 2^(12) bytes */
#define MAX_PARAM_NUMBER 10

typedef struct {
    char url[MAX_URL_LENGTH];
    RequestType type;
    SimplePacket content;
    Param params[MAX_PARAM_NUMBER];
    int paramNumber;
} RequestBuilder;


extern char static_command[(MAX_PARAM_NUMBER * MAX_PARAM_FIELDS_LENGTH * 2) + MAX_URL_LENGTH + MAX_SIMPLE_PACKET_DATA_LENGTH + 200];
extern char static_output[(MAX_SIMPLE_PACKET_DATA_LENGTH * 2) + 200];

/**
 * Init the static_request builder.
 *
 * Set requestType to Get.
 * @param req the static_request changed.
 */
void initRequestBuilder(RequestBuilder *req);

/**
 * Set the url of the static_request.
 * @param req the static_request changed.
 * @param url the new url of req.
 */
void setRequestUrl(RequestBuilder *req, char *url);

/**
 * Adding some text at the end of the url.
 * @param req the static_request changed.
 * @param additionalUrl the text concatenated to the url.
 */
void concatToRequestUrl(RequestBuilder *req, char *additionalUrl);

/**
 * Adding a param to the static_request.
 * @param req the static_request changed.
 * @param name the name of the Param.
 * @param value the value of the Param.
 */
void addParamToRequest(RequestBuilder *req, char *name, char *value);

/**
 * Set the content of the static_request builder.
 * @param req the static_request changed.
 * @param data the string setted to data.
 */
void setContent(RequestBuilder *req, char *data);

/**
 * Send the Request from the requestBuilder, and put the response int the response packet.
 * @param req the static_request sent.
 * @param response it will fill the response.
 */
void sendRequest(RequestBuilder *req, SimplePacket *response);

void buildCommand(RequestBuilder *req);

void parseJsonToSimplePacket(char *json, SimplePacket *packet);

#endif //CLIENT_C_CURL_H
