#include "curl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

char static_command[
        (MAX_PARAM_NUMBER * MAX_PARAM_FIELDS_LENGTH * 2) + MAX_URL_LENGTH + MAX_SIMPLE_PACKET_DATA_LENGTH + 200];
char static_output[(MAX_SIMPLE_PACKET_DATA_LENGTH * 2) + 200];


/**
 * Reset or init
 * @param req
 */
void initRequestBuilder(RequestBuilder *req) {
    req->type = GET;
    req->paramNumber = 0;
    strcpy(req->url, "");
}

void setRequestUrl(RequestBuilder *req, char *url) {
    strcpy(req->url, url);
}

void concatToRequestUrl(RequestBuilder *req, char *additionalUrl) {
    strcat(req->url, additionalUrl);
}

void addParamToRequest(RequestBuilder *req, char *name, char *value) {
    strcpy(req->params[req->paramNumber].name, name);
    strcpy(req->params[req->paramNumber].value, value);
    req->paramNumber++;
}

void setContent(RequestBuilder *req, char *data) {
    req->type = POST;
    strcpy(req->content.data, data);
}

void buildCommand(RequestBuilder *req) {
    strcpy(static_command, "");
    strcat(static_command, CURL_PATH);
    strcat(static_command, " \"");
    strcat(static_command, req->url);

    if (req->paramNumber != 0) {
        strcat(static_command, "?");
        bool first = true;
        for (int i = 0; i < req->paramNumber; i++) {
            if (!first)
                strcat(static_command, "&");
            else
                first = false;

            strcat(static_command, req->params[i].name);
            strcat(static_command, "=");
            strcat(static_command, req->params[i].value);
        }
    }

    strcat(static_command, "\" ");

    if (req->type == POST) {
        strcat(static_command, "-H \"Content-Type: application/json\" ");
        strcat(static_command, "--data \"");
        strcat(static_command, "{\\\"data\\\":\\\"");
        strcat(static_command, req->content.data);
        strcat(static_command, "\\\",\\\"toShow\\\":\\\"\\\"}\"");
    }

    strcat(static_command, " 2> curl.err");
}


void sendRequest(RequestBuilder *req, SimplePacket *response) {
    buildCommand(req);

    FILE *fp;
    fp = popen(static_command, "r");
    if (fp == NULL) {
        exit(-1);
    }

    strcpy(static_output, "");
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        strcat(static_output, buffer);
    }

    pclose(fp);

    parseJsonToSimplePacket(static_output, response);
}

void parseJsonToSimplePacket(char *json, SimplePacket *packet) {
    int last = 0;
    int occurrence = 0;
    bool isData = false;
    bool isToShow = false;
    for (int i = 0; static_output[i] != '\0'; i++) {
        if (static_output[i] == '"') {
            if (occurrence == 1) {
                isData = !strncmp("data", static_output + last + 1, 4);
                isToShow = !strncmp("toShow", static_output + last + 1, 6);
                if (!strncmp("status", static_output + last + 1, 6)) {
                    printf("\n\nREQUEST ERROR : %s\n\n", json);
                    exit(-1);
                }
            } else if (occurrence == 3) {
                if (isData) {
                    strncpy(packet->data, static_output + last + 1, i - last - 1);
                    packet->data[i - last - 1] = '\0';
                } else if (isToShow) {
                    strncpy(packet->toShow, static_output + last + 1, i - last - 1);
                    packet->toShow[i - last - 1] = '\0';
                }
            }
            last = i;
            occurrence++;
        } else if (occurrence != 3 && static_output[i] == ',') {
            occurrence = 0;
        }

        if (static_output[i] == '\\')
            i++;
    }

}