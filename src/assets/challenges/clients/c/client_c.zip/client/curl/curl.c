#include "curl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

char static_command[
    MAX_PARAM_NUMBER * MAX_PARAM_FIELDS_LENGTH * 2 + MAX_URL_LENGTH + MAX_SIMPLE_PACKET_DATA_LENGTH + 200];
char static_output[MAX_SIMPLE_PACKET_DATA_LENGTH * 2 + 200];


/**
 * Reset or init
 * @param req
 */
void initRequestBuilder(RequestBuilder* req) {
    req->type = GET;
    req->paramNumber = 0;
    strcpy(req->url, "");
}

void setRequestUrl(RequestBuilder* req, char* url) {
    strcpy(req->url, url);
}

void concatToRequestUrl(RequestBuilder* req, char* additionalUrl) {
    strcat(req->url, additionalUrl);
}

void addParamToRequest(RequestBuilder* req, char* name, char* value) {
    strcpy(req->params[req->paramNumber].name, name);
    strcpy(req->params[req->paramNumber].value, value);
    req->paramNumber++;
}

void setContent(RequestBuilder* req, char* data) {
    req->type = POST;
    strcpy(req->content.data, data);
}

void buildCommand(RequestBuilder* req) {
    strcpy(static_command, "");
    strcat(static_command, CURL_PATH);
    strcat(static_command, " \"");
    strcat(static_command, req->url);

    if (req->paramNumber != 0) {
        strcat(static_command, "?");
        bool first = true;
        for (int i = 0; i < req->paramNumber; i++) {
            if (!first)
                strcat(static_command, "&");
            else
                first = false;

            strcat(static_command, req->params[i].name);
            strcat(static_command, "=");
            strcat(static_command, req->params[i].value);
        }
    }

    strcat(static_command, "\" ");

    if (req->type == POST) {
        strcat(static_command, "-H \"Content-Type: application/json\" ");
        strcat(static_command, "--data \"");
        strcat(static_command, "{\\\"data\\\":\\\"");
        strcat(static_command, req->content.data);
        strcat(static_command, "\\\",\\\"toShow\\\":\\\"\\\"}\"");
    }

    strcat(static_command, " 2> curl.err");
}


void sendRequest(RequestBuilder* req, SimplePacket* response) {
    buildCommand(req);

    FILE* fp;
    fp = popen(static_command, "r");
    if (fp == NULL) {
        exit(-1);
    }

    strcpy(static_output, "");
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        strcat(static_output, buffer);
    }

    pclose(fp);

    parseJsonToSimplePacket(static_output, response);
    parseTextFromHTMLRequest(response->data);
    parseTextFromHTMLRequest(response->toShow);
}

void str_replace(char* target, const char* needle, const char* replacement);

void parseJsonToSimplePacket(char* json, SimplePacket* packet) {
    int last = 0;
    int occurrence = 0;
    bool isData = false;
    bool isToShow = false;
    for (int i = 0; static_output[i] != '\0'; i++) {
        if (static_output[i] == '"') {
            if (occurrence == 1) {
                isData = !strncmp("data", static_output + last + 1, 4);
                isToShow = !strncmp("toShow", static_output + last + 1, 6);
                if (!strncmp("status", static_output + last + 1, 6)) {
                    printf("\n\nREQUEST ERROR : %s\n\n", json);
                    exit(-1);
                }
            }
            else if (occurrence == 3) {
                if (isData) {
                    strncpy(packet->data, static_output + last + 1, i - last - 1);
                    packet->data[i - last - 1] = '\0';
                }
                else if (isToShow) {
                    strncpy(packet->toShow, static_output + last + 1, i - last - 1);
                    packet->toShow[i - last - 1] = '\0';
                }
            }
            last = i;
            occurrence++;
        }
        else if (occurrence != 3 && static_output[i] == ',') {
            occurrence = 0;
        }

        if (static_output[i] == '\\')
            i++;
    }
    str_replace(packet->data, "\\\"", "\"");
    str_replace(packet->toShow, "\\\"", "\"");

    str_replace(packet->data, "\\\\\"", "\\\"");
    str_replace(packet->toShow, "\\\\\"", "\\\"");
}


void parseTextFromHTMLRequest(char* text) {
    int current_index = 0;
    for (int i = 0; text[i] != '\0'; i++) {
        if (text[i + 1] != '\0' && !strncmp(text + i, "\\n", 2)) {
            text[current_index++] = '\n';
            i++; // Consume another index
        }
        else {
#ifdef _WIN32 // HANDLE SHITTY WINDOWS TERMINAL !!!
            if (text[i] == -61) {
                i++;
                if (text[i] == -87) {
                    // é
                    text[current_index++] = -126;
                }
                else if (text[i] == -96) {
                    // à
                    text[current_index++] = -123;
                }
                else if (text[i] == -88) {
                    // è
                    text[current_index++] = -118;
                }
                else if (text[i] == -86) {
                    // ê
                    text[current_index++] = -120;
                }
                else if (text[i] == -89) {
                }
                else {
                    printf("%c%c\n", -61, text[i]);
                    printf("COMPLEX CHAR un handled for windows terminal ! %d", text[i]);
                    exit(1);
                }
            }
            else {
                text[current_index++] = text[i];
            }
#else // set in linux terminal.
            text[current_index++] = text[i];
#endif
        }
    }
    text[current_index] = '\0';
}

/**
 * src : https://stackoverflow.com/questions/32413667/replace-all-occurrences-of-a-substring-in-a-string-in-c
 */
void str_replace(char* target, const char* needle, const char* replacement) {
    char buffer[1024] = {0};
    char* insert_point = &buffer[0];
    const char* tmp = target;
    size_t needle_len = strlen(needle);
    size_t repl_len = strlen(replacement);

    while (1) {
        const char* p = strstr(tmp, needle);

        // walked past last occurrence of needle; copy remaining part
        if (p == NULL) {
            strcpy(insert_point, tmp);
            break;
        }

        // copy part before needle
        memcpy(insert_point, tmp, p - tmp);
        insert_point += p - tmp;

        // copy replacement string
        memcpy(insert_point, replacement, repl_len);
        insert_point += repl_len;

        // adjust pointers, move on
        tmp = p + needle_len;
    }

    // write altered string back to target
    strcpy(target, buffer);
}
