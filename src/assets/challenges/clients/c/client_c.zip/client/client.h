#ifndef CLIENT_C_CLIENT_H
#define CLIENT_C_CLIENT_H

#include "curl/curl.h"

#ifdef _WIN32
#define SEND_PREFIX ">>"
#define RECEIVE_PREFIX "<<"
#else
#define SEND_PREFIX "\033[0;33m>>"
#define RECEIVE_PREFIX "\033[0;34m<<"
#endif

extern char static_domain[200];
extern char static_key[15];
extern RequestBuilder static_request;
extern char static_sessionId[10];
extern SimplePacket static_receive;

void initDefaultClient(char *key);

void initClientWithDomain(char *key, char *domain);

void exchangeSessionId();

char *loadChallenge(char *challenge);

char *start();

char *submit(char *data);

char *submitInt(int value);

char *submitCompleteRequest(char *action, char *data);

void printWithPrefix(char *prefix, char *text);


#endif //CLIENT_C_CLIENT_H