#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "client.h"


char static_domain[200];
char static_key[15];
RequestBuilder static_request;
char static_sessionId[10];
SimplePacket static_receive;


void initDefaultClient(char* key) {
    initClientWithDomain(key, "https://devarea.fr/data/");
}

void initClientWithDomain(char* key, char* domain) {
    strcpy(static_key, key);
    strcpy(static_domain, domain);
    exchangeSessionId();
    if (static_sessionId[0] == '\0') {
        fprintf(stderr, "IMPOSSIBLE DE METTRE EN PLACE LA CONNEXION !\n");
#ifdef _WIN32
        fprintf(stderr, "You can check 'curl.err' file next to the client_c.exe.");
#else
        fprintf(stderr, "You may try to use 'sudo apt install curl' to resolve the problem.\n");
        fprintf(stderr, "You can check 'curl.err' file next to the client_c output.\n");
#endif
        exit(-1);
    }
#ifdef _WIN32
    printf("Client connected. SessionId : %s.\n", static_sessionId);
#else
    printf("\033[0;35mClient connected. SessionId : %s.\n", static_sessionId);
#endif
}

void exchangeSessionId() {
    initRequestBuilder(&static_request);

    setRequestUrl(&static_request, static_domain);
    concatToRequestUrl(&static_request, "challenges/create_session");
    addParamToRequest(&static_request, "key", static_key);
    addParamToRequest(&static_request, "lang", "C");

    sendRequest(&static_request, &static_receive);

    strcpy(static_sessionId, static_receive.data);
}

char* loadChallenge(char* challenge) {
#ifdef _WIN32
    printf(" >> load %s\n", challenge);
#else
    printf(" \033[0;33m>> load %s\n", challenge);
#endif

    initRequestBuilder(&static_request);

    setRequestUrl(&static_request, static_domain);
    concatToRequestUrl(&static_request, "challenges/load_challenge");
    addParamToRequest(&static_request, "sessionId", static_sessionId);
    addParamToRequest(&static_request, "challenge", challenge);

    sendRequest(&static_request, &static_receive);

    printWithPrefix(RECEIVE_PREFIX, static_receive.toShow);

    return static_receive.data;
}

char* start() {
    return submitCompleteRequest("start", "start");
}

char* submit(char* data) {
    return submitCompleteRequest("", data);
}

char* submitInt(int value) {
    char number[10];
    sprintf(number, "%d", value);
    return submit(number);
}

char* submitCompleteRequest(char* action, char* data) {
    printWithPrefix(SEND_PREFIX, data);

    initRequestBuilder(&static_request);
    setRequestUrl(&static_request, static_domain);
    concatToRequestUrl(&static_request, "challenges/execute_on_challenge/");
    concatToRequestUrl(&static_request, action);
    addParamToRequest(&static_request, "sessionId", static_sessionId);
    setContent(&static_request, data);

    sendRequest(&static_request, &static_receive);

    printWithPrefix(RECEIVE_PREFIX, static_receive.toShow);

    return static_receive.data;
}


void printWithPrefix(char* prefix, char* text) {
    printf(" %s ", prefix);
    int size = 0;
    for (int i = 0; text[i] != '\0'; i++) {
        if (text[i] == '\n') {
            printf("\n %s ", prefix);
            size = 0;
        }
        else if (size >= 85) {
            printf("\n %s %c", prefix, text[i]);
            size = 1;
        }
        else {
            size++;
            printf("%c", text[i]);
        }
    }
    printf("\n");
}
