package devarea.client;

import java.util.HashMap;
import java.util.Map;

public class SimplePacket {

    protected String data;
    protected String toShow;

    public SimplePacket(final String data) {
        this.data = data;
        this.toShow = "";
    }

    public SimplePacket(final String data, final String toShow) {
        this.data = data;
        this.toShow = toShow;
    }

    public String getData() {
        return data;
    }

    public String getToShow() {
        return toShow;
    }

    public String toJson() {
        return "{\"data\":\"" + this.data + "\",\"toShow\":\"" + toShow + "\"}";
    }

    public static SimplePacket parseString(final String json) {
        Map<String, String> maps = convertStringToMap(json);
        return new SimplePacket(maps.get("data").replace("\\n", "\n"), maps.get("toShow").replace("\\n", "\n"));
    }

    public static Map<String, String> convertStringToMap(String data) {
        HashMap<String, String> map = new HashMap<>();

        int i = 0;
        int start = -1;
        String flag = null;
        while (i < data.length()) {
            if (data.charAt(i) == '"') {
                if (flag == null) {
                    if (start == -1) {
                        start = i;
                    } else {
                        flag = data.substring(start + 1, i).replace("\\\"", "\"").replace("\\\\", "\\");
                        start = -1;
                    }
                } else {
                    if (start == -1) {
                        start = i;
                    } else {
                        map.put(flag, data.substring(start+1, i).replace("\\\"", "\"").replace("\\\\", "\\"));
                        flag = null;
                        start = -1;
                    }
                }
            }

            if (data.charAt(i) == '\\') {
                i++;
            }

            i++;
        }

        return map;
    }

}
